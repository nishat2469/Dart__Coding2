void printName(){
  print("Nishat Tanjum");
}
void main() {
  printName();
}