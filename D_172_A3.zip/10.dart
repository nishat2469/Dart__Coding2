void isEven(int num){
  if (num % 2 == 0) {
    print("True");
  } else {
    print("False");
  }
}
void main() {
  isEven(4);
}