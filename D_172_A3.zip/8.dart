void add(int num1, int num2){
  int sum = num1 + num2;
  print("Sum: $sum");
}
void main() {
  add(5, 10);
}