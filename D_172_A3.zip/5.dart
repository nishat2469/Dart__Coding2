void area(double radius) {
  double area = 3.14 * radius * radius;
  print("Area of the circle: $area");
  
}
void main() {
  area(5);
}