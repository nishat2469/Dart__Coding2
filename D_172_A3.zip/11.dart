void createUser(String name, int age,bool isActive) {

  print("Name: $name");
  print("Age: $age");
  print("ID Active: $isActive");
}
void main() {
  createUser("John",25,true);
}