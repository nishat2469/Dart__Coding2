void calculateArea(double length, double width) {
  double area = length * width;
  print("Area of the rectangle: $area");
}
void main() {
  calculateArea(10.0, 5.0);
}